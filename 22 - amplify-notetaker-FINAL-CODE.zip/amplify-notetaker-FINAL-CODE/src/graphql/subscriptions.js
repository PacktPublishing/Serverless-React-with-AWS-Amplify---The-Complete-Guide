// eslint-disable
// this is an auto generated file. This will be overwritten

export const onCreateNote = `subscription OnCreateNote {
  onCreateNote {
    id
    note
  }
}
`;
export const onUpdateNote = `subscription OnUpdateNote {
  onUpdateNote {
    id
    note
  }
}
`;
export const onDeleteNote = `subscription OnDeleteNote {
  onDeleteNote {
    id
    note
  }
}
`;
